﻿// See https://aka.ms/new-console-template for more information
using Newtonsoft.Json;
using System.Net.Http.Headers;

bool program = true;

HttpClient client = new HttpClient();
client.BaseAddress = new Uri("https://api.exchangerate.host/latest");


client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));


while (program)
{
    Console.WriteLine("============MENU============");
    Console.WriteLine("1. Przelicz walutę");
    Console.WriteLine("2. Koniec");
    Console.WriteLine("============================");

    if (int.TryParse(Console.ReadLine(), out int opt))
    {
        if (opt == 1)
        {
            Console.WriteLine("Podaj kwotę w zł:");

            if (decimal.TryParse(Console.ReadLine(), out decimal amount))
            {
                Console.WriteLine("Podaj kod waluty:");
                string code = Console.ReadLine();   

                HttpResponseMessage response = client.GetAsync("?base=PLN").Result;

                if (response.IsSuccessStatusCode)
                {
                    var json = await response.Content.ReadAsStringAsync();

                    dynamic data = JsonConvert.DeserializeObject(json);

                    foreach (var r in data.rates)
                    {
                        if (r.Name.ToLower() == code.ToLower())
                        {
                            decimal rate = (decimal)r.Value;
                            decimal result = Math.Round(amount * rate, 2);
                            Console.WriteLine("Posiadasz: " + result + " " + code);
                            break;
                        }
                    }
                }
                else
                {
                    Console.WriteLine("Wystąpił błąd połączenia");
                }

            }
            else
            {
                Console.WriteLine("Niepoprawna kwota!");
            }
        }
        else
        {
            program = false;
        }
    }
    else
    {
        Console.WriteLine("Niepoprawny numer opcji");
    }
}
